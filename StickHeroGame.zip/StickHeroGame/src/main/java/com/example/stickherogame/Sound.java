package com.example.stickherogame;

public class Sound {
    public static void playSound(){}
}
