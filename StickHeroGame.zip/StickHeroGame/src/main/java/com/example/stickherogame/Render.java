package com.example.stickherogame;

public interface Render {
    public void render();
}
