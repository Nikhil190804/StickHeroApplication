package com.example.stickherogame;

public interface Movable {
    public double move(double distance);
}
