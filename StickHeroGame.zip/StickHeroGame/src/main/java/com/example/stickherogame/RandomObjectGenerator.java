package com.example.stickherogame;

public interface RandomObjectGenerator {
    public static   void randomGenerator(){
    }
}
