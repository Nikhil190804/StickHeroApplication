package com.example.stickherogame;

import javafx.event.ActionEvent;

public class ControllerSceneOne {
    public void playbutton(ActionEvent event){}
    public void help(ActionEvent event){}

    public void sound(ActionEvent event){}

    public void skins(ActionEvent event){}

    public void loadAndSave(ActionEvent event){}

}
