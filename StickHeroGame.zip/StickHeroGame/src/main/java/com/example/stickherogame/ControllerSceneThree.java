package com.example.stickherogame;

import javafx.event.ActionEvent;

public class ControllerSceneThree {
    public void home(ActionEvent event){}

    public void restart(ActionEvent event){}
}
